<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* Update these values for the SMTP account used by this application. */
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_user'] = 'fernandezregalcher@gmail.com';
$config['smtp_pass'] = 'dzjgfofbhqmceimr';
$config['smtp_port'] = 587;
$config['smtp_crypto'] = 'tls';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";
$config['crlf'] = "\r\n";
$config['wordwrap'] = TRUE;
<?php

class Emailer extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->load->view('formPage');
    }

    public function sendEmail()
    {
        $this->form_validation->set_rules('recipient', 'Recipient', 'trim|required|valid_email');
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required');
        $this->form_validation->set_rules('message', 'Message', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('errors', $this->form_validation->error_array());
            redirect('emailer/index');
            return;
        }

        $attachment_path = NULL;

if (!empty($_FILES['attachment']['name'])) {
    // 1. Define folder path explicitly using FCPATH (root directory where index.php lives)
    $upload_dir = FCPATH . 'uploads';

    // 2. Convert to absolute system path and append trailing separator
    $resolved_path = realpath($upload_dir);
    
    if ($resolved_path === FALSE) {
        $this->session->set_flashdata('errors', array('attachment' => 'Target upload path could not be resolved on the server filesystem.'));
        redirect('emailer/index');
        return;
    }

    $final_upload_path = $resolved_path . DIRECTORY_SEPARATOR;

    // 4. Configure Upload Library
    $upload_config = array(
        'upload_path'   => $final_upload_path,
        'allowed_types' => 'pdf|doc|docx|xls|xlsx|jpg|jpeg|png|txt|zip',
        'max_size'      => 10240,
        'encrypt_name'  => TRUE,
        'remove_spaces' => TRUE
    );

    // 5. Initialize/Load Library with fresh config
    $this->load->library('upload');
    $this->upload->initialize($upload_config);

    if (!$this->upload->do_upload('attachment')) {
        $this->session->set_flashdata('errors', array('attachment' => $this->upload->display_errors('', '')));
        redirect('emailer/index');
        return;
    }

    $attachment_path = $this->upload->data('full_path');
}

        $this->load->config('email');
        $smtp_config = array(
            'protocol' => $this->config->item('protocol'),
            'smtp_host' => $this->config->item('smtp_host'),
            'smtp_user' => $this->config->item('smtp_user'),
            'smtp_pass' => $this->config->item('smtp_pass'),
            'smtp_port' => $this->config->item('smtp_port'),
            'smtp_crypto' => $this->config->item('smtp_crypto'),
            'mailtype' => $this->config->item('mailtype'),
            'charset' => $this->config->item('charset'),
            'newline' => $this->config->item('newline'),
            'crlf' => $this->config->item('crlf'),
            'wordwrap' => $this->config->item('wordwrap')
        );

        $this->load->library('email');
        $this->email->initialize($smtp_config);
        $this->email->from($this->config->item('smtp_user'), 'ANONYMOUS PHILIPPINES');
        $this->email->to($this->input->post('recipient', TRUE));
        $this->email->subject($this->input->post('subject', TRUE));
        $this->email->message(nl2br(html_escape($this->input->post('message', TRUE))));

        if ($attachment_path !== NULL) {
            $this->email->attach($attachment_path);
        }

        $sent = $this->email->send();
        if ($attachment_path !== NULL && is_file($attachment_path)) {
            unlink($attachment_path);
        }

        if ($sent) {
            $this->session->set_flashdata('success', 'Email sent successfully.');
        } else {
            $error_message = $this->email->print_debugger(array('headers'));
            $this->session->set_flashdata('errors', array('email' => strip_tags($error_message)));
        }

        redirect('emailer/index');
    }
}

?>
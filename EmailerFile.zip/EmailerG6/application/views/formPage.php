<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Emailer</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css">
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
</head>
<body>
    <div style="display:flex;align-items:center;justify-content:center;min-height:100vh;">
        <div style="width:100%;max-width:500px;padding:20px;">
            <h2 style="text-align:center; margin-bottom:20px;">Send Email</h2>

            <form method="POST" enctype="multipart/form-data" action="<?php echo site_url('emailer/sendEmail'); ?>">
                <div style="margin-bottom:15px;">
                    <label for="recipient">Recipient</label>
                    <input type="email" id="recipient" name="recipient" placeholder="recipient@example.com" required style="width:100%;padding:8px;box-sizing:border-box;">
                </div>

                <div style="margin-bottom:15px;">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="Email subject" required style="width:100%;padding:8px;box-sizing:border-box;">
                </div>

                <div style="margin-bottom:15px;">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" placeholder="Write your message" required style="width:100%;padding:8px;box-sizing:border-box;"></textarea>
                </div>

                <div style="margin-bottom:15px;">
                    <label for="attachment">Attachment</label>
                    <input type="file" id="attachment" name="attachment" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.txt,.zip" style="width:100%;padding:8px;box-sizing:border-box;">
                    <div style="font-size:12px; color:#666; margin-top:5px;">Optional. Maximum size: 10 MB.</div>
                </div>

                <button type="submit" style="width:100%;padding:10px;background:#0d6efd;color:#fff;border:none;border-radius:4px;cursor:pointer;">Send Email</button>
            </form>
        </div>
    </div>

    <?php $errors = $this->session->flashdata('errors'); ?>
    <?php $success = $this->session->flashdata('success'); ?>

    <script>
        alertify.set('notifier', 'position', 'top-right');

        <?php if (!empty($errors)) : ?>
            <?php foreach ($errors as $error) : ?>
                alertify.error('<?php echo addslashes($error); ?>');
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if (!empty($success)) : ?>
            alertify.success('<?php echo addslashes($success); ?>');
        <?php endif; ?>
    </script>
</body>
</html>